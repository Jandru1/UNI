create table pokemon(
 id  number(8,0), --PK
 nombre char(20),
 tipus number(17,0),
 tipus2 number(17,0),
 entrenador char(100),
 descripcion char(250)
) PCTFREE 0;

DECLARE id int;
pn int;
i int;
nz INT;
nombre CHAR(20);
tipus INT;

begin
pn:= 1;
for i in 1..2000 loop
	if (pn = 1) then 
		id := i;
	else
		id := 1002 - i;
	END if;
	nz := (id - 1) Mod 7 + 1;
	tipus := (id - 1) mod 16 + 1;
	if (nz = 1) then nombre := 'Pikachu'; END if;
	if (nz = 2) then nombre := 'Bulbasour'; END if;
	if (nz = 3) then nombre := 'Charizard'; END if;
	if (nz = 4) then nombre := 'Metapod'; END if;
	if (nz = 5) then nombre := 'Squirtle'; END if;
	if (nz = 6) then nombre := 'Meowth'; END if;
	if (nz = 7) then nombre := 'Chikorita'; END if;
	insert into pokemon values (id, nombre, tipus, 15, 'ent' || id, 'descr' || id);
	pn:=pn * (-1);
end loop;
end;

-- Actualitzar estadÌstiques
DECLARE
esquema VARCHAR2(100);
CURSOR c IS SELECT TABLE_NAME FROM USER_TABLES WHERE TABLE_NAME NOT LIKE 'SHADOW_%';
BEGIN
SELECT '"'||sys_context('USERENV', 'CURRENT_SCHEMA')||'"' INTO esquema FROM dual;
FOR taula IN c LOOP
  DBMS_STATS.GATHER_TABLE_STATS( 
    ownname => esquema, 
    tabname => taula.table_name, 
    estimate_percent => NULL,
    method_opt =>'FOR ALL COLUMNS SIZE REPEAT',
    granularity => 'GLOBAL',
    cascade => TRUE
    );
  END LOOP;
END;
   
SELECT entrenador from pokemon where id = 23;

SELECT TABLE_NAME, BLOCKS, NUM_ROWS FROM USER_TABLES;



--2a part B+

CREATE UNIQUE INDEX name ON POKEMON (id) PCTFREE 33;

-- Actualitzar estadÌstiques
DECLARE
esquema VARCHAR2(100);
CURSOR c IS SELECT TABLE_NAME FROM USER_TABLES WHERE TABLE_NAME NOT LIKE 'SHADOW_%';
BEGIN
SELECT '"'||sys_context('USERENV', 'CURRENT_SCHEMA')||'"' INTO esquema FROM dual;
FOR taula IN c LOOP
  DBMS_STATS.GATHER_TABLE_STATS( 
    ownname => esquema, 
    tabname => taula.table_name, 
    estimate_percent => NULL,
    method_opt =>'FOR ALL COLUMNS SIZE REPEAT',
    granularity => 'GLOBAL',
    cascade => TRUE
    );
  END LOOP;
END;


SELECT PCT_FREE, BLEVEL, LEAF_BLOCKS, DISTINCT_KEYS FROM USER_INDEXES;
         
SELECT * FROM USER_TS_QUOTAS;

--Cost Oracle = 2
--Cost Teóric = h + d = 1+1 = 2  
--Oracle el fa servir

--3a part HASH

DROP INDEX name
DROP TABLE POKEMON

CREATE CLUSTER name (id NUMBER(8,0)) SINGLE TABLE HASHKEYS 130 PCTFREE 0; 

create table pokemon(
 id  number(8,0),
 nombre char(20),
 tipus number(17,0),
 tipus2 number(17,0),
 entrenador char(100),
 descripcion char(250)
) CLUSTER name2(id);

DECLARE id int;
pn int;
i int;
nz INT;
nombre CHAR(20);
tipus INT;

begin
pn:= 1;
for i in 1..2000 loop
	if (pn = 1) then 
		id := i;
	else
		id := 1002 - i;
	END if;
	nz := (id - 1) Mod 7 + 1;
	tipus := (id - 1) mod 16 + 1;
	if (nz = 1) then nombre := 'Pikachu'; END if;
	if (nz = 2) then nombre := 'Bulbasour'; END if;
	if (nz = 3) then nombre := 'Charizard'; END if;
	if (nz = 4) then nombre := 'Metapod'; END if;
	if (nz = 5) then nombre := 'Squirtle'; END if;
	if (nz = 6) then nombre := 'Meowth'; END if;
	if (nz = 7) then nombre := 'Chikorita'; END if;
	insert into pokemon values (id, nombre, tipus, 15, 'ent' || id, 'descr' || id);
	pn:=pn * (-1);
end loop;
end;

-- Actualitzar estadÌstiques
DECLARE
esquema VARCHAR2(100);
CURSOR c IS SELECT TABLE_NAME FROM USER_TABLES WHERE TABLE_NAME NOT LIKE 'SHADOW_%';
BEGIN
SELECT '"'||sys_context('USERENV', 'CURRENT_SCHEMA')||'"' INTO esquema FROM dual;
FOR taula IN c LOOP
  DBMS_STATS.GATHER_TABLE_STATS( 
    ownname => esquema, 
    tabname => taula.table_name, 
    estimate_percent => NULL,
    method_opt =>'FOR ALL COLUMNS SIZE REPEAT',
    granularity => 'GLOBAL',
    cascade => TRUE
    );
  END LOOP;
END;


SELECT * FROM USER_TS_QUOTAS;

--Cost Teóric = k + 1 = 2 
--Cost oracle = 0
--Oracle no el fa servir 


