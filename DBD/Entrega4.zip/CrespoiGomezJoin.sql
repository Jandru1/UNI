--JOIN

create table Entrenador(
 id number(8,0),
 pokemonid number(8,0),
 gimnasio char(20),
 descripcion char(250)
) PCTFREE 0;

create table Pokemon(
 id number(8,0),
 nombre char(20),
 tipus number(17,0),
 tipus2 number(17,0)
) PCTFREE 0;

DECLARE id int;
pn int;
i int;
pokemonid int;
nz INT;
descripcionE CHAR(250);
tipus INT;
tipus2 INT;
nombre CHAR(20);

begin
pn:= 1;
for i in 1..3000 loop
	if (pn = 1) then 
		id := i;
	else
		id := 3002 - i;
	END if;
	nz := (id - 1) Mod 6 + 1;
	pokemonid := (id - 1) mod 555 + 1;
	if (nz = 1) then descripcionE := 'Bueno'; END if;
	if (nz = 2) then descripcionE := 'Regular'; END if;
	if (nz = 3) then descripcionE := 'Malo'; END if;
	if (nz = 4) then descripcionE := 'Rechoncho'; END if;
	if (nz = 5) then descripcionE := 'Mamadisimo'; END if;
	if (nz = 6) then descripcionE := 'Pessimo'; END if;
	insert into Entrenador values (id, pokemonid , 'gim' || id, descripcionE);
	pn:=pn * (-1);
end loop;

pn:= 1;
for i in 1..7000 loop
	if (pn = 1) then 
		id := i;
	else
		id := 7002 - i;
	END if;
	tipus := (id - 1) mod 10 + 1;
	tipus2 := (id - 1) MOD 12 + 1;
	nz := (id - 1) Mod 7 + 1;
	if (nz = 1) then nombre := 'Pikachu'; END if;
	if (nz = 2) then nombre := 'Bulbasour'; END if;
	if (nz = 3) then nombre := 'Charizard'; END if;
	if (nz = 4) then nombre := 'Metapod'; END if;
	if (nz = 5) then nombre := 'Squirtle'; END if;
	if (nz = 6) then nombre := 'Meowth'; END if;
	if (nz = 7) then nombre := 'Chikorita'; END if;
	insert into Pokemon values (id, nombre, tipus, tipus2);
    pn:=pn * (-1);
end loop;
end;

-- Entrenador  ------------------------------------   Pokemon
-- Actualitzar estadistiques

DECLARE
esquema VARCHAR2(100);
CURSOR c IS SELECT TABLE_NAME FROM USER_TABLES WHERE TABLE_NAME NOT LIKE 'SHADOW_%';
BEGIN
SELECT '"'||sys_context('USERENV', 'CURRENT_SCHEMA')||'"' INTO esquema FROM dual;
FOR taula IN c LOOP
  DBMS_STATS.GATHER_TABLE_STATS( 
    ownname => esquema, 
    tabname => taula.table_name, 
    estimate_percent => NULL,
    method_opt =>'FOR ALL COLUMNS SIZE REPEAT',
    granularity => 'GLOBAL',
    cascade => TRUE
    );
  END LOOP;
END;


SELECT e.id, e.gimnasio, e.descripcion, p.nombre, p.tipus
FROM Entrenador e, Pokemon p
WHERE e.pokemonid = p.id;

SELECT TABLE_NAME, BLOCKS, NUM_ROWS FROM USER_TABLES;



-- Entrenador Btree ------------------------------------     Pokemon

CREATE UNIQUE INDEX name ON Entrenador (id) PCTFREE 33;

-- Actualitzar estadistiques
DECLARE
esquema VARCHAR2(100);
CURSOR c IS SELECT TABLE_NAME FROM USER_TABLES WHERE TABLE_NAME NOT LIKE 'SHADOW_%';
BEGIN
SELECT '"'||sys_context('USERENV', 'CURRENT_SCHEMA')||'"' INTO esquema FROM dual;
FOR taula IN c LOOP
  DBMS_STATS.GATHER_TABLE_STATS( 
    ownname => esquema, 
    tabname => taula.table_name, 
    estimate_percent => NULL,
    method_opt =>'FOR ALL COLUMNS SIZE REPEAT',
    granularity => 'GLOBAL',
    cascade => TRUE
    );
  END LOOP;
END;

SELECT PCT_FREE, BLEVEL, LEAF_BLOCKS, DISTINCT_KEYS FROM USER_INDEXES;

SELECT * FROM USER_TS_QUOTAS;

-- Cost teoric = BR·D+|R|·(hS·D+((k-1)/uS)·D+k·D) = 35·1 + 7000·(1+((3000-1)/375)·1+3000) = 21063016,33
-- Cost Oracle = 147
-- Oracle no el fa servir



-- Entrenador Hash ------------------------------------     Pokemon
DROP INDEX name;
DROP TABLE Entrenador;

CREATE CLUSTER name3 (id NUMBER(8,0)) SINGLE TABLE HASHKEYS 138 PCTFREE 0;

create table Entrenador(
 id number(8,0),
 pokemonid number(8,0),
 gimnasio char(20),
 descripcion char(250)
) CLUSTER name3(id);

DECLARE id int;
pn int;
i int;
pokemonid int;
nz INT;
descripcionE CHAR(250);

begin
pn:= 1;
for i in 1..3000 loop
	if (pn = 1) then 
		id := i;
	else
		id := 3002 - i;
	END if;
	nz := (id - 1) Mod 6 + 1;
	pokemonid := (id - 1) mod 555 + 1;
	if (nz = 1) then descripcionE := 'Bueno'; END if;
	if (nz = 2) then descripcionE := 'Regular'; END if;
	if (nz = 3) then descripcionE := 'Malo'; END if;
	if (nz = 4) then descripcionE := 'Rechoncho'; END if;
	if (nz = 5) then descripcionE := 'Mamadisimo'; END if;
	if (nz = 6) then descripcionE := 'Pessimo'; END if;
	insert into Entrenador values (id, pokemonid , 'gim' || id, descripcionE);
	pn:=pn * (-1);
end loop;
END;


-- Actualitzar estadistiques
DECLARE
esquema VARCHAR2(100);
CURSOR c IS SELECT TABLE_NAME FROM USER_TABLES WHERE TABLE_NAME NOT LIKE 'SHADOW_%';
BEGIN
SELECT '"'||sys_context('USERENV', 'CURRENT_SCHEMA')||'"' INTO esquema FROM dual;
FOR taula IN c LOOP
  DBMS_STATS.GATHER_TABLE_STATS( 
    ownname => esquema, 
    tabname => taula.table_name, 
    estimate_percent => NULL,
    method_opt =>'FOR ALL COLUMNS SIZE REPEAT',
    granularity => 'GLOBAL',
    cascade => TRUE
    );
  END LOOP;
END;


SELECT * FROM USER_TS_QUOTAS;

-- Cost teoric = k+1 = 3001
-- Cost Oracle = 188
-- Oracle el fa servir




-- Entrenador ------------------------------------     Pokemon Btree

DROP TABLE ENTRENADOR;
DROP CLUSTER name3;

create table Entrenador(
 id number(8,0),
 pokemonid number(8,0),
 gimnasio char(20),
 descripcion char(250)
) PCTFREE 0;

DECLARE id int;
pn int;
i int;
pokemonid int;
nz INT;
descripcionE CHAR(250);

begin
pn:= 1;
for i in 1..3000 loop
	if (pn = 1) then 
		id := i;
	else
		id := 3002 - i;
	END if;
	nz := (id - 1) Mod 6 + 1;
	pokemonid := (id - 1) mod 555 + 1;
	if (nz = 1) then descripcionE := 'Bueno'; END if;
	if (nz = 2) then descripcionE := 'Regular'; END if;
	if (nz = 3) then descripcionE := 'Malo'; END if;
	if (nz = 4) then descripcionE := 'Rechoncho'; END if;
	if (nz = 5) then descripcionE := 'Mamadisimo'; END if;
	if (nz = 6) then descripcionE := 'Pessimo'; END if;
	insert into Entrenador values (id, pokemonid , 'gim' || id, descripcionE);
	pn:=pn * (-1);
end loop;
END;

CREATE UNIQUE INDEX name4 ON POKEMON (id) PCTFREE 33;

-- Actualitzar estadistiques
DECLARE
esquema VARCHAR2(100);
CURSOR c IS SELECT TABLE_NAME FROM USER_TABLES WHERE TABLE_NAME NOT LIKE 'SHADOW_%';
BEGIN
SELECT '"'||sys_context('USERENV', 'CURRENT_SCHEMA')||'"' INTO esquema FROM dual;
FOR taula IN c LOOP
  DBMS_STATS.GATHER_TABLE_STATS( 
    ownname => esquema, 
    tabname => taula.table_name, 
    estimate_percent => NULL,
    method_opt =>'FOR ALL COLUMNS SIZE REPEAT',
    granularity => 'GLOBAL',
    cascade => TRUE
    );
  END LOOP;
END;

SELECT PCT_FREE, BLEVEL, LEAF_BLOCKS, DISTINCT_KEYS FROM USER_INDEXES;

SELECT * FROM USER_TS_QUOTAS;

--PCT  Blevel leaf 
--33	1	19	7000

-- Cost teoric = BR·D+|R|·(hS·D+((k-1)/uS)·D+k·D) = 35 +7000·(1+((3000-1)/369)+3000)= 21063926,6
-- Cost Oracle = 147
-- Oracle no el fa servir


-- Entrenador ------------------------------------     Pokemon Hash

DROP INDEX name4;
DROP TABLE POKEMON;

CREATE CLUSTER name5 (id NUMBER(8,0)) SINGLE TABLE HASHKEYS 138 PCTFREE 0;

create table pokemon(
 id number(8,0),
 nombre char(20),
 tipus number(17,0),
 tipus2 number(17,0)
) CLUSTER name5(id);


DECLARE id int;
pn int;
i int;
nz INT;
tipus INT;
tipus2 INT;
nombre CHAR(20);

begin
pn:= 1;
for i in 1..7000 loop
	if (pn = 1) then 
		id := i;
	else
		id := 7002 - i;
	END if;
	tipus := (id - 1) mod 10 + 1;
	tipus2 := (id - 1) MOD 12 + 1;
	nz := (id - 1) Mod 7 + 1;
	if (nz = 1) then nombre := 'Pikachu'; END if;
	if (nz = 2) then nombre := 'Bulbasour'; END if;
	if (nz = 3) then nombre := 'Charizard'; END if;
	if (nz = 4) then nombre := 'Metapod'; END if;
	if (nz = 5) then nombre := 'Squirtle'; END if;
	if (nz = 6) then nombre := 'Meowth'; END if;
	if (nz = 7) then nombre := 'Chikorita'; END if;
	insert into Pokemon values (id, nombre, tipus, tipus2);
    pn:=pn * (-1);
end loop;
end;


-- Actualitzar estadistiques
DECLARE
esquema VARCHAR2(100);
CURSOR c IS SELECT TABLE_NAME FROM USER_TABLES WHERE TABLE_NAME NOT LIKE 'SHADOW_%';
BEGIN
SELECT '"'||sys_context('USERENV', 'CURRENT_SCHEMA')||'"' INTO esquema FROM dual;
FOR taula IN c LOOP
  DBMS_STATS.GATHER_TABLE_STATS( 
    ownname => esquema, 
    tabname => taula.table_name, 
    estimate_percent => NULL,
    method_opt =>'FOR ALL COLUMNS SIZE REPEAT',
    granularity => 'GLOBAL',
    cascade => TRUE
    );
  END LOOP;
END;

SELECT * FROM USER_TS_QUOTAS;

-- Cost teoric = 7000*3000 + 110 = 21000110
-- Cost Oracle = 111
-- Oracle no el fa servir

-- Entrenador Btree ------------------------------------     Pokemon Btree

DROP TABLE POKEMON;
DROP TABLE ENTRENADOR;
DROP CLUSTER name5;

create table Entrenador(
 id number(8,0),
 pokemonid number(8,0),
 gimnasio char(20),
 descripcion char(250)
) PCTFREE 0;

create table pokemon(
 id number(8,0),
 nombre char(20),
 tipus number(17,0),
 tipus2 number(17,0)
) PCTFREE 0;

DECLARE id int;
pn int;
i int;
pokemonid int;
nz INT;
descripcionE CHAR(250);
tipus INT;
tipus2 INT;
nombre CHAR(20);

begin
pn:= 1;
for i in 1..3000 loop
	if (pn = 1) then 
		id := i;
	else
		id := 3002 - i;
	END if;
	nz := (id - 1) Mod 6 + 1;
	pokemonid := (id - 1) mod 555 + 1;
	if (nz = 1) then descripcionE := 'Bueno'; END if;
	if (nz = 2) then descripcionE := 'Regular'; END if;
	if (nz = 3) then descripcionE := 'Malo'; END if;
	if (nz = 4) then descripcionE := 'Rechoncho'; END if;
	if (nz = 5) then descripcionE := 'Mamadisimo'; END if;
	if (nz = 6) then descripcionE := 'Pessimo'; END if;
	insert into Entrenador values (id, pokemonid , 'gim' || id, descripcionE);
	pn:=pn * (-1);
end loop;

pn:= 1;
for i in 1..7000 loop
	if (pn = 1) then 
		id := i;
	else
		id := 7002 - i;
	END if;
	tipus := (id - 1) mod 10 + 1;
	tipus2 := (id - 1) MOD 12 + 1;
	nz := (id - 1) Mod 7 + 1;
	if (nz = 1) then nombre := 'Pikachu'; END if;
	if (nz = 2) then nombre := 'Bulbasour'; END if;
	if (nz = 3) then nombre := 'Charizard'; END if;
	if (nz = 4) then nombre := 'Metapod'; END if;
	if (nz = 5) then nombre := 'Squirtle'; END if;
	if (nz = 6) then nombre := 'Meowth'; END if;
	if (nz = 7) then nombre := 'Chikorita'; END if;
	insert into Pokemon values (id, nombre, tipus, tipus2);
    pn:=pn * (-1);
end loop;
end;

CREATE UNIQUE INDEX pokIndex ON POKEMON (id) PCTFREE 33;
CREATE UNIQUE INDEX entIndex ON ENTRENADOR (id) PCTFREE 33;

-- Actualitzar estadistiques
DECLARE
esquema VARCHAR2(100);
CURSOR c IS SELECT TABLE_NAME FROM USER_TABLES WHERE TABLE_NAME NOT LIKE 'SHADOW_%';
BEGIN
SELECT '"'||sys_context('USERENV', 'CURRENT_SCHEMA')||'"' INTO esquema FROM dual;
FOR taula IN c LOOP
  DBMS_STATS.GATHER_TABLE_STATS( 
    ownname => esquema, 
    tabname => taula.table_name, 
    estimate_percent => NULL,
    method_opt =>'FOR ALL COLUMNS SIZE REPEAT',
    granularity => 'GLOBAL',
    cascade => TRUE
    );
  END LOOP;
END;

SELECT PCT_FREE, BLEVEL, LEAF_BLOCKS, DISTINCT_KEYS FROM USER_INDEXES;

SELECT * FROM USER_TS_QUOTAS;

--Pct blevel leaf distinct
--33	1	19	7000
--33	1	8	3000

-- Cost teoric = BR·D+|R|·(hS·D+((k-1)/uS)·D+k·D) = 35+7000(1+((3000-1)/158)+3000) = 21139902,09
-- Cost Oracle = 147
-- Oracle no el fa servir


-- Entrenador Btree ------------------------------------     Pokemon Hash

DROP INDEX pokIndex;
DROP TABLE POKEMON;

CREATE CLUSTER name6 (id NUMBER(8,0)) SINGLE TABLE HASHKEYS 138 PCTFREE 0;

create table pokemon(
 id number(8,0),
 nombre char(20),
 tipus number(17,0),
 tipus2 number(17,0)
) CLUSTER name6(id);

DECLARE id int;
pn int;
i int;
nz INT;
tipus INT;
tipus2 INT;
nombre CHAR(20);

begin
pn:= 1;
for i in 1..7000 loop
	if (pn = 1) then 
		id := i;
	else
		id := 7002 - i;
	END if;
	tipus := (id - 1) mod 10 + 1;
	tipus2 := (id - 1) MOD 12 + 1;
	nz := (id - 1) Mod 7 + 1;
	if (nz = 1) then nombre := 'Pikachu'; END if;
	if (nz = 2) then nombre := 'Bulbasour'; END if;
	if (nz = 3) then nombre := 'Charizard'; END if;
	if (nz = 4) then nombre := 'Metapod'; END if;
	if (nz = 5) then nombre := 'Squirtle'; END if;
	if (nz = 6) then nombre := 'Meowth'; END if;
	if (nz = 7) then nombre := 'Chikorita'; END if;
	insert into Pokemon values (id, nombre, tipus, tipus2);
    pn:=pn * (-1);
end loop;
end;

-- Actualitzar estadistiques
DECLARE
esquema VARCHAR2(100);
CURSOR c IS SELECT TABLE_NAME FROM USER_TABLES WHERE TABLE_NAME NOT LIKE 'SHADOW_%';
BEGIN
SELECT '"'||sys_context('USERENV', 'CURRENT_SCHEMA')||'"' INTO esquema FROM dual;
FOR taula IN c LOOP
  DBMS_STATS.GATHER_TABLE_STATS( 
    ownname => esquema, 
    tabname => taula.table_name, 
    estimate_percent => NULL,
    method_opt =>'FOR ALL COLUMNS SIZE REPEAT',
    granularity => 'GLOBAL',
    cascade => TRUE
    );
  END LOOP;
END;

SELECT * FROM USER_TS_QUOTAS;

-- Cost teoric = 110 +3000*(1+3000) = 9003110
-- Cost Oracle = 111
-- Oracle no el fa servir

-- Entrenador Hash ------------------------------------     Pokemon Hash

DROP INDEX entIndex;
DROP TABLE ENTRENADOR;

CREATE CLUSTER name7 (id NUMBER(8,0)) SINGLE TABLE HASHKEYS 138 PCTFREE 0;

create table Entrenador(
 id number(8,0),
 pokemonid number(8,0),
 gimnasio char(20),
 descripcion char(250)
) CLUSTER name7(id);

DECLARE id int;
pn int;
i int;
pokemonid int;
nz INT;
descripcionE CHAR(250);

begin
pn:= 1;
for i in 1..3000 loop
	if (pn = 1) then 
		id := i;
	else
		id := 3002 - i;
	END if;
	nz := (id - 1) Mod 6 + 1;
	pokemonid := (id - 1) mod 555 + 1;
	if (nz = 1) then descripcionE := 'Bueno'; END if;
	if (nz = 2) then descripcionE := 'Regular'; END if;
	if (nz = 3) then descripcionE := 'Malo'; END if;
	if (nz = 4) then descripcionE := 'Rechoncho'; END if;
	if (nz = 5) then descripcionE := 'Mamadisimo'; END if;
	if (nz = 6) then descripcionE := 'Pessimo'; END if;
	insert into Entrenador values (id, pokemonid , 'gim' || id, descripcionE);
	pn:=pn * (-1);
end loop;
END;

-- Actualitzar estadistiques
DECLARE
esquema VARCHAR2(100);
CURSOR c IS SELECT TABLE_NAME FROM USER_TABLES WHERE TABLE_NAME NOT LIKE 'SHADOW_%';
BEGIN
SELECT '"'||sys_context('USERENV', 'CURRENT_SCHEMA')||'"' INTO esquema FROM dual;
FOR taula IN c LOOP
  DBMS_STATS.GATHER_TABLE_STATS( 
    ownname => esquema, 
    tabname => taula.table_name, 
    estimate_percent => NULL,
    method_opt =>'FOR ALL COLUMNS SIZE REPEAT',
    granularity => 'GLOBAL',
    cascade => TRUE
    );
  END LOOP;
END;


SELECT * FROM USER_TS_QUOTAS;

-- Cost teoric = BR + |R|·(1+k) = 151 + 3000·(1+3000) =  9003151
-- Cost Oracle = 152
-- Oracle el fa servir 


-- Entrenador Hash ------------------------------------     Pokemon Btree

DROP TABLE POKEMON;
DROP CLUSTER name7;


create table pokemon(
 id number(8,0),
 nombre char(20),
 tipus number(17,0),
 tipus2 number(17,0)
) PCTFREE 0;

DECLARE id int;
pn int;
i int;
nz INT;
tipus INT;
tipus2 INT;
nombre CHAR(20);

begin
pn:= 1;
for i in 1..7000 loop
	if (pn = 1) then 
		id := i;
	else
		id := 7002 - i;
	END if;
	tipus := (id - 1) mod 10 + 1;
	tipus2 := (id - 1) MOD 12 + 1;
	nz := (id - 1) Mod 7 + 1;
	if (nz = 1) then nombre := 'Pikachu'; END if;
	if (nz = 2) then nombre := 'Bulbasour'; END if;
	if (nz = 3) then nombre := 'Charizard'; END if;
	if (nz = 4) then nombre := 'Metapod'; END if;
	if (nz = 5) then nombre := 'Squirtle'; END if;
	if (nz = 6) then nombre := 'Meowth'; END if;
	if (nz = 7) then nombre := 'Chikorita'; END if;
	insert into Pokemon values (id, nombre, tipus, tipus2);
    pn:=pn * (-1);
end loop;
end;

CREATE UNIQUE INDEX name8 ON Pokemon (id) PCTFREE 33;

-- Actualitzar estadistiques
DECLARE
esquema VARCHAR2(100);
CURSOR c IS SELECT TABLE_NAME FROM USER_TABLES WHERE TABLE_NAME NOT LIKE 'SHADOW_%';
BEGIN
SELECT '"'||sys_context('USERENV', 'CURRENT_SCHEMA')||'"' INTO esquema FROM dual;
FOR taula IN c LOOP
  DBMS_STATS.GATHER_TABLE_STATS( 
    ownname => esquema, 
    tabname => taula.table_name, 
    estimate_percent => NULL,
    method_opt =>'FOR ALL COLUMNS SIZE REPEAT',
    granularity => 'GLOBAL',
    cascade => TRUE
    );
  END LOOP;
END;

SELECT * FROM USER_TS_QUOTAS;



-- Cost teoric = BR + |R|·(1+k) = 35 + 7000 * (1+3000) = 21007035              
-- Cost Oracle = 188
-- Oracle el fa servir





DROP TABLE ALUMNEUPC;
DROP CLUSTER alumneHash;
DROP TABLE PROJECTE;
DROP INDEX projIndex;
