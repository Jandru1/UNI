El lider d’un gimnas de tipo X ha de tenir algún pokemon capturat de naturaleza X. 
Un pokemon capturat que resideix a una pokeball amb identificador X ha de pertanyer a l’entrenador propietari de la pokeball amb identificador X.

CREATE TABLE Pokemon (
Id_Pokemon Integer,
Naturaleza VARCHAR(1),
PRIMARY KEY (Id_Pokemon));

CREATE TABLE Entrenador (
Nom_Entr VARCHAR(1),
Edad Integer,
Sexo VARCHAR(1),
Nom_Gimnasio VARCHAR(1) UNIQUE,
Dirección_Gimnasio VARCHAR(1),
Tipo_Gimnasio VARCHAR(1), 
PRIMARY KEY (Nom_Entr));
 
CREATE TABLE Capturado (
Nom_Pokemon VARCHAR(1),
Id_Pokemon Integer,
Nom_Entr varchar(1) NOT NULL,
FOREIGN KEY (Id_Pokemon) REFERENCES Pokemon(Id_Pokemon),
FOREIGN KEY (Nom_Entr) REFERENCES Entrenador(Nom_Entr),
PRIMARY KEY (Id_Pokemon));

CREATE TABLE Pokeball (
Id_Pokeball Integer,
Color VARCHAR(1),
Tipo VARCHAR(1),
Nom_Pokemon VARCHAR(1) UNIQUE,
Nom_Entr varchar(1) NOT NULL,
FOREIGN KEY (Nom_Pokemon) REFERENCES Capturado(Nom_Pokemon),
FOREIGN KEY (Nom_Entr) REFERENCES Entrenador(Nom_Entr),
PRIMARY KEY (Id_Pokeball));
 

CREATE ASSERTION A1 ( 
(NOT EXISTS (SELECT e.nom_entr
			FROM ENTRENADOR e, CAPTURADO c, Pokemon pk
			WHERE e.NOM_ENTR = c.NOM_ENTR AND c.ID_POKEMON = pk.ID_POKEMON AND 
				pk.NATURALEZA <> e.TIPO_GIMNASIO)
			GROUP BY e.NOM_ENTR));

CREATE MATERIALIZED VIEW MVA1
	BUILD IMMEDIATE REFRESH COMPLETE ON DEMAND AS( 
	SELECT 'x' AS x 
			FROM ENTRENADOR e, CAPTURADO c, POKEMON pk
			WHERE e.NOM_ENTR = c.NOM_ENTR AND c.ID_POKEMON = pk.ID_POKEMON AND 
				pk.NATURALEZA <> e.TIPO_GIMNASIO
			GROUP BY e.NOM_ENTR);
ALTER TABLE MVA1 ADD CONSTRAINT MVA1_check CHECK (x IS NULL);

--INSERTS SALTA VIEW MVA1

INSERT INTO ENTRENADOR
VALUES ('BROCK', '17', 'M', 'Pewter','Ciudad Plateada', 'Roca');

INSERT INTO POKEMON
VALUES ('095', 'Volador');

INSERT INTO CAPTURADO
VALUES ('Onix', '095', 'BROCK');


CREATE ASSERTION A2 
(NOT EXISTS (SELECT c.ID_POKEMON
			FROM ENTRENADOR e, CAPTURADO c, POKEBALL pb
			WHERE e.NOM_ENTR = c.NOM_ENTR AND e.NOM_ENTR <> pb.NOM_ENTR AND 
				pb.ID_POKEMON = c.ID_POKEMON)
			GROUP BY c.ID_POKEMON);

CREATE MATERIALIZED VIEW MVA2 
	BUILD IMMEDIATE Refresh Complete ON DEMAND AS( 
	SELECT 'x' AS x
			FROM ENTRENADOR e, CAPTURADO c, POKEBALL pb
			WHERE e.NOM_ENTR = c.NOM_ENTR AND e.NOM_ENTR <> pb.NOM_ENTR AND 
				pb.ID_POKEMON = c.ID_POKEMON
			GROUP BY c.ID_POKEMON);
ALTER TABLE MVA2 ADD CONSTRAINT mva2_check CHECK (x IS NULL);

--INSERTS SALTA VIEW MVA2
INSERT INTO ENTRENADOR
VALUES ('ASH', '15', 'M', NULL, NULL, NULL);

INSERT INTO POKEMON
VALUES ('096', 'Roca');

INSERT INTO CAPTURADO
VALUES ('Geodude', '096', 'BROCK');

INSERT INTO POKEBALL
VALUES ('123', 'violeta-rosa', 'masterball', '096', 'ASH');



--INSERT OKEY TOT BÉ
INSERT INTO ENTRENADOR
VALUES ('BROCK', '17', 'M', 'Pewter','Ciudad Plateada', 'Roca');

INSERT INTO POKEMON
VALUES ('095', 'Volador');

INSERT INTO CAPTURADO
VALUES ('Onix', '095', 'BROCK');