#!/bin/bash

#SBATCH --job-name=submit-extrae.sh
#SBATCH -D .
#SBATCH --output=submit-extrae.sh.o%j
#SBATCH --error=submit-extrae.sh.e%j

USAGE="\n USAGE: ./submit-omp.sh prog-omp numthreads cutoff \n
    prog-omp    -> Program name \n
    numthreads  -> Number of threads in parallel execution \n
    cutoff      -> level to stop task generation (optional) \n"

if (test $# -lt 2 || test $# -gt 3)
then
    echo -e $USAGE
    exit 0
fi

HOST=$(echo $HOSTNAME | cut -f 1 -d'.')

if (test "${HOST}" = "boada-1")
then
    echo "Use sbatch to execute this script"
    exit 0
fi

PROG=$1
make $PROG

export OMP_NUM_THREADS=$2
export OMP_WAIT_POLICY="passive"

export size=128
export sort_size=128
export merge_size=128
export cutoff=16

export LD_PRELOAD=${EXTRAE_HOME}/lib/libomptrace.so

if (test $# -eq 3)
then
    export cutoff=$3
    ./$PROG -n $size -s $sort_size -m $merge_size -c $cutoff > ${PROG}_${OMP_NUM_THREADS}_${cutoff}_${HOST}.times.txt
else
    ./$PROG -n $size -s $sort_size -m $merge_size > ${PROG}_${OMP_NUM_THREADS}_${HOST}.times.txt
fi

unset LD_PRELOAD
mpi2prv -f TRACE.mpits -o ${PROG}_${OMP_NUM_THREADS}_${HOST}.prv -e $PROG -paraver
rm -rf TRACE.mpits TRACE.sym set-0
